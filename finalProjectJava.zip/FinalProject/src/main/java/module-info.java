module com.finalproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.finalproject to javafx.fxml;
    exports com.finalproject;
}
